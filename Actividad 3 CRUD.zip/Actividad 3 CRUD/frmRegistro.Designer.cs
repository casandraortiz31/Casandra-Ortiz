﻿namespace Actividad_3_CRUD
{
    partial class frmRegistro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRegistro));
            this.groupdatos = new System.Windows.Forms.GroupBox();
            this.txtApellido = new System.Windows.Forms.TextBox();
            this.txttelefono = new System.Windows.Forms.TextBox();
            this.txtfec_nac = new System.Windows.Forms.TextBox();
            this.txtid = new System.Windows.Forms.TextBox();
            this.txtdireccion = new System.Windows.Forms.TextBox();
            this.txtnombre = new System.Windows.Forms.TextBox();
            this.labelphone = new System.Windows.Forms.Label();
            this.labelMat = new System.Windows.Forms.Label();
            this.labelfecha = new System.Windows.Forms.Label();
            this.labelapellido = new System.Windows.Forms.Label();
            this.labelnombre = new System.Windows.Forms.Label();
            this.labeldni = new System.Windows.Forms.Label();
            this.buttonAgregar = new System.Windows.Forms.Button();
            this.buttonModificar = new System.Windows.Forms.Button();
            this.buttonEliminar = new System.Windows.Forms.Button();
            this.labelEmail = new System.Windows.Forms.Label();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.Mostrar = new System.Windows.Forms.DataGridView();
            this.akirasBoutiquesDataSet = new Actividad_3_CRUD.AkirasBoutiquesDataSet();
            this.clienteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.clienteTableAdapter = new Actividad_3_CRUD.AkirasBoutiquesDataSetTableAdapters.ClienteTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.groupdatos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Mostrar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.akirasBoutiquesDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clienteBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // groupdatos
            // 
            this.groupdatos.Controls.Add(this.txtemail);
            this.groupdatos.Controls.Add(this.labelEmail);
            this.groupdatos.Controls.Add(this.txtApellido);
            this.groupdatos.Controls.Add(this.txttelefono);
            this.groupdatos.Controls.Add(this.txtfec_nac);
            this.groupdatos.Controls.Add(this.txtid);
            this.groupdatos.Controls.Add(this.txtdireccion);
            this.groupdatos.Controls.Add(this.txtnombre);
            this.groupdatos.Controls.Add(this.labelphone);
            this.groupdatos.Controls.Add(this.labelMat);
            this.groupdatos.Controls.Add(this.labelfecha);
            this.groupdatos.Controls.Add(this.labelapellido);
            this.groupdatos.Controls.Add(this.labelnombre);
            this.groupdatos.Controls.Add(this.labeldni);
            this.groupdatos.Location = new System.Drawing.Point(44, 34);
            this.groupdatos.Name = "groupdatos";
            this.groupdatos.Size = new System.Drawing.Size(381, 282);
            this.groupdatos.TabIndex = 2;
            this.groupdatos.TabStop = false;
            this.groupdatos.Text = "Datos de Cliente";
            // 
            // txtApellido
            // 
            this.txtApellido.Location = new System.Drawing.Point(176, 97);
            this.txtApellido.Name = "txtApellido";
            this.txtApellido.Size = new System.Drawing.Size(180, 20);
            this.txtApellido.TabIndex = 23;
            // 
            // txttelefono
            // 
            this.txttelefono.Location = new System.Drawing.Point(126, 212);
            this.txttelefono.Name = "txttelefono";
            this.txttelefono.Size = new System.Drawing.Size(243, 20);
            this.txttelefono.TabIndex = 22;
            // 
            // txtfec_nac
            // 
            this.txtfec_nac.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.txtfec_nac.Location = new System.Drawing.Point(196, 173);
            this.txtfec_nac.Name = "txtfec_nac";
            this.txtfec_nac.Size = new System.Drawing.Size(173, 20);
            this.txtfec_nac.TabIndex = 21;
            this.txtfec_nac.Text = "aaaa/mm/dd";
            this.txtfec_nac.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtid
            // 
            this.txtid.Location = new System.Drawing.Point(139, 32);
            this.txtid.Name = "txtid";
            this.txtid.Size = new System.Drawing.Size(217, 20);
            this.txtid.TabIndex = 20;
            // 
            // txtdireccion
            // 
            this.txtdireccion.Location = new System.Drawing.Point(176, 140);
            this.txtdireccion.Name = "txtdireccion";
            this.txtdireccion.Size = new System.Drawing.Size(193, 20);
            this.txtdireccion.TabIndex = 19;
            // 
            // txtnombre
            // 
            this.txtnombre.Location = new System.Drawing.Point(139, 63);
            this.txtnombre.Name = "txtnombre";
            this.txtnombre.Size = new System.Drawing.Size(217, 20);
            this.txtnombre.TabIndex = 18;
            // 
            // labelphone
            // 
            this.labelphone.AutoSize = true;
            this.labelphone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelphone.Location = new System.Drawing.Point(28, 212);
            this.labelphone.Name = "labelphone";
            this.labelphone.Size = new System.Drawing.Size(79, 16);
            this.labelphone.TabIndex = 17;
            this.labelphone.Text = "TELEFONO";
            // 
            // labelMat
            // 
            this.labelMat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMat.Location = new System.Drawing.Point(24, 141);
            this.labelMat.Name = "labelMat";
            this.labelMat.Size = new System.Drawing.Size(146, 20);
            this.labelMat.TabIndex = 16;
            this.labelMat.Text = "DIRECCION";
            // 
            // labelfecha
            // 
            this.labelfecha.AutoSize = true;
            this.labelfecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelfecha.Location = new System.Drawing.Point(24, 177);
            this.labelfecha.Name = "labelfecha";
            this.labelfecha.Size = new System.Drawing.Size(166, 16);
            this.labelfecha.TabIndex = 15;
            this.labelfecha.Text = "FECHA DE NACIMIENTO :";
            // 
            // labelapellido
            // 
            this.labelapellido.AutoSize = true;
            this.labelapellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelapellido.Location = new System.Drawing.Point(24, 98);
            this.labelapellido.Name = "labelapellido";
            this.labelapellido.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.labelapellido.Size = new System.Drawing.Size(71, 16);
            this.labelapellido.TabIndex = 14;
            this.labelapellido.Text = "APELLIDO";
            // 
            // labelnombre
            // 
            this.labelnombre.AutoSize = true;
            this.labelnombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelnombre.Location = new System.Drawing.Point(24, 68);
            this.labelnombre.Name = "labelnombre";
            this.labelnombre.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.labelnombre.Size = new System.Drawing.Size(84, 16);
            this.labelnombre.TabIndex = 13;
            this.labelnombre.Text = "NOMBRE(s):";
            // 
            // labeldni
            // 
            this.labeldni.AutoSize = true;
            this.labeldni.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeldni.Location = new System.Drawing.Point(24, 36);
            this.labeldni.Name = "labeldni";
            this.labeldni.Size = new System.Drawing.Size(26, 16);
            this.labeldni.TabIndex = 12;
            this.labeldni.Text = "ID :";
            // 
            // buttonAgregar
            // 
            this.buttonAgregar.BackColor = System.Drawing.Color.Cyan;
            this.buttonAgregar.Location = new System.Drawing.Point(500, 47);
            this.buttonAgregar.Name = "buttonAgregar";
            this.buttonAgregar.Size = new System.Drawing.Size(175, 53);
            this.buttonAgregar.TabIndex = 3;
            this.buttonAgregar.Text = "AGREGAR";
            this.buttonAgregar.UseVisualStyleBackColor = false;
            this.buttonAgregar.Click += new System.EventHandler(this.buttonAgregar_Click);
            // 
            // buttonModificar
            // 
            this.buttonModificar.BackColor = System.Drawing.Color.Lime;
            this.buttonModificar.Location = new System.Drawing.Point(442, 129);
            this.buttonModificar.Name = "buttonModificar";
            this.buttonModificar.Size = new System.Drawing.Size(119, 39);
            this.buttonModificar.TabIndex = 4;
            this.buttonModificar.Text = "MODIFICAR";
            this.buttonModificar.UseVisualStyleBackColor = false;
            // 
            // buttonEliminar
            // 
            this.buttonEliminar.BackColor = System.Drawing.Color.Red;
            this.buttonEliminar.Location = new System.Drawing.Point(599, 129);
            this.buttonEliminar.Name = "buttonEliminar";
            this.buttonEliminar.Size = new System.Drawing.Size(118, 39);
            this.buttonEliminar.TabIndex = 5;
            this.buttonEliminar.Text = "ELIMINAR";
            this.buttonEliminar.UseVisualStyleBackColor = false;
            this.buttonEliminar.Click += new System.EventHandler(this.buttonEliminar_Click);
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEmail.Location = new System.Drawing.Point(31, 246);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(51, 18);
            this.labelEmail.TabIndex = 24;
            this.labelEmail.Text = "EMAIL";
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(126, 247);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(243, 20);
            this.txtemail.TabIndex = 25;
            // 
            // Mostrar
            // 
            this.Mostrar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Mostrar.Location = new System.Drawing.Point(44, 307);
            this.Mostrar.Name = "Mostrar";
            this.Mostrar.Size = new System.Drawing.Size(673, 150);
            this.Mostrar.TabIndex = 6;
            this.Mostrar.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // akirasBoutiquesDataSet
            // 
            this.akirasBoutiquesDataSet.DataSetName = "AkirasBoutiquesDataSet";
            this.akirasBoutiquesDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // clienteBindingSource
            // 
            this.clienteBindingSource.DataMember = "Cliente";
            this.clienteBindingSource.DataSource = this.akirasBoutiquesDataSet;
            // 
            // clienteTableAdapter
            // 
            this.clienteTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Yellow;
            this.button1.Location = new System.Drawing.Point(500, 236);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(175, 62);
            this.button1.TabIndex = 7;
            this.button1.Text = "MOSTRAR TABLA";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // frmRegistro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(729, 509);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Mostrar);
            this.Controls.Add(this.buttonEliminar);
            this.Controls.Add(this.buttonModificar);
            this.Controls.Add(this.buttonAgregar);
            this.Controls.Add(this.groupdatos);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmRegistro";
            this.Text = "REGISTRO";
            this.Load += new System.EventHandler(this.frmRegistro_Load);
            this.groupdatos.ResumeLayout(false);
            this.groupdatos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Mostrar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.akirasBoutiquesDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clienteBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupdatos;
        private System.Windows.Forms.Button buttonAgregar;
        private System.Windows.Forms.Button buttonModificar;
        private System.Windows.Forms.Button buttonEliminar;
        private System.Windows.Forms.TextBox txtApellido;
        private System.Windows.Forms.TextBox txttelefono;
        private System.Windows.Forms.TextBox txtfec_nac;
        private System.Windows.Forms.TextBox txtid;
        private System.Windows.Forms.TextBox txtdireccion;
        private System.Windows.Forms.TextBox txtnombre;
        private System.Windows.Forms.Label labelphone;
        private System.Windows.Forms.Label labelMat;
        private System.Windows.Forms.Label labelfecha;
        private System.Windows.Forms.Label labelapellido;
        private System.Windows.Forms.Label labelnombre;
        private System.Windows.Forms.Label labeldni;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.DataGridView Mostrar;
        private AkirasBoutiquesDataSet akirasBoutiquesDataSet;
        private System.Windows.Forms.BindingSource clienteBindingSource;
        private AkirasBoutiquesDataSetTableAdapters.ClienteTableAdapter clienteTableAdapter;
        private System.Windows.Forms.Button button1;
    }
}