﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
namespace Actividad_3_CRUD
{
    public partial class frmRegistro : Form
    {
        public frmRegistro()
        {
            InitializeComponent();
        }

        private void frmRegistro_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'akirasBoutiquesDataSet.Cliente' Puede moverla o quitarla según sea necesario.
            this.clienteTableAdapter.Fill(this.akirasBoutiquesDataSet.Cliente);

        }

        private void buttonAgregar_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=DESKTOP-J3EBORT\\SQLEXPRESS;Initial Catalog=AkirasBoutiques;Integrated Security=True;Encrypt=False"))
            {
                if (txtid.Text == "" || txtnombre.Text == "" || txtApellido.Text == "" || txtdireccion.Text == "" || txtfec_nac.Text == "" || txttelefono.Text == "" || txtemail.Text == "")
                {
                    MessageBox.Show("Necesitas llenar los datos requeridos.");
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("Update Cliente set Nombre '" + txtnombre.Text + "','" + txtApellido.Text + "','" + txtdireccion + "','" + txtfec_nac.Text + "','" + txttelefono.Text + "','" + txtemail.Text + "' ,Where ID '" + txtid.Text + "')", cn);
                    cmd.CommandType = CommandType.Text;
                    cn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Cliente registrado exitosamente");
                    txtid.Clear();
                    txtnombre.Clear();
                    txtApellido.Clear();
                    txtdireccion.Clear();
                    txtfec_nac.Clear();
                    txttelefono.Clear();
                    txtemail.Clear();
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void buttonEliminar_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=DESKTOP-J3EBORT\\SQLEXPRESS;Initial Catalog=AkirasBoutiques;Integrated Security=True;Encrypt=False"))
            {
                if (txtid.Text == "" || txtnombre.Text == "" || txtApellido.Text == "" || txtdireccion.Text == "" || txtfec_nac.Text == "" || txttelefono.Text == "" || txtemail.Text == "")
                {
                    MessageBox.Show("Necesitas llenar los datos requeridos.");
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("Update Cliente set Nombre '" + txtnombre.Text + "','" + txtApellido.Text + "','" + txtdireccion + "','" + txtfec_nac.Text + "','" + txttelefono.Text + "','" + txtemail.Text + "' ,Where ID '" + txtid.Text + "')", cn);
                    cmd.CommandType = CommandType.Text;
                    cn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Cliente registrado exitosamente");
                    txtid.Clear();
                    txtnombre.Clear();
                    txtApellido.Clear();
                    txtdireccion.Clear();
                    txtfec_nac.Clear();
                    txttelefono.Clear();
                    txtemail.Clear();
                }
            }
        }
    }