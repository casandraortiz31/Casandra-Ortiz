﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Act_2.Clases
{
    public class clssopcion1
    {
        public string Saludar (string Nombre)
        {
            string saludo;
            saludo = "Hola" + Nombre + ", Que tengas un excelente dia.";
            return saludo;
        }
    }
}
