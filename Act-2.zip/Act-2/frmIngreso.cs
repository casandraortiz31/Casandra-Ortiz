﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Act_2
{
    public partial class frmIngreso : Form
    {
        public frmIngreso()
        {
            InitializeComponent();
        }

        private void ButtonIngresar_Click(object sender, EventArgs e)
        {
            if(textpassword.Text == "")
            {

                MessageBox.Show("Debe ingresar");
            }
            else if (textpassword.Text == "12345678")
            {
                Form1 opcion1 = new Form1();
                opcion1.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("contraseña incorrecta");
                textpassword.Clear();
            }
        }

        private void frmIngreso_Load(object sender, EventArgs e)
        {

        }

        private void textpassword_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
