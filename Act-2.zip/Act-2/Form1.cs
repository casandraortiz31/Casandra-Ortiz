﻿using Act_2.Formularios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Act_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void opcion1ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void opcion1ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Formularios.frmSaludo frmSaludo = new Formularios.frmSaludo();
            frmSaludo.Show();
        }

        private void operacionesBasicasToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void operacionBasicaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmOperaciones Menu = new frmOperaciones();
            Menu.Show();
        }

        private void datosPersonalesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void informacionPersonalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmInformacion Menu = new frmInformacion();
            Menu.Show();
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void datosClinicosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDatosClinicos Menu = new frmDatosClinicos();
            Menu.Show();
        }
    }
}
