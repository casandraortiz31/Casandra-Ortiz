﻿namespace Act_2
{
    partial class frmIngreso
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textpassword = new System.Windows.Forms.TextBox();
            this.txtcontraseña = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ButtonIngresar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textpassword
            // 
            this.textpassword.Location = new System.Drawing.Point(214, 137);
            this.textpassword.Name = "textpassword";
            this.textpassword.PasswordChar = '*';
            this.textpassword.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textpassword.Size = new System.Drawing.Size(136, 20);
            this.textpassword.TabIndex = 9;
            this.textpassword.TextChanged += new System.EventHandler(this.textpassword_TextChanged);
            // 
            // txtcontraseña
            // 
            this.txtcontraseña.AutoSize = true;
            this.txtcontraseña.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcontraseña.Location = new System.Drawing.Point(105, 137);
            this.txtcontraseña.Name = "txtcontraseña";
            this.txtcontraseña.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtcontraseña.Size = new System.Drawing.Size(105, 18);
            this.txtcontraseña.TabIndex = 8;
            this.txtcontraseña.Text = "Contraseña :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(85, 83);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label2.Size = new System.Drawing.Size(305, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Presentado por : Casandra Montserrat Ortiz Cortes";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(61, 52);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label1.Size = new System.Drawing.Size(359, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "UNIVERSIDAD MEXICO  INTERNACIONAL";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ButtonIngresar
            // 
            this.ButtonIngresar.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ButtonIngresar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ButtonIngresar.Location = new System.Drawing.Point(214, 192);
            this.ButtonIngresar.Name = "ButtonIngresar";
            this.ButtonIngresar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ButtonIngresar.Size = new System.Drawing.Size(102, 36);
            this.ButtonIngresar.TabIndex = 5;
            this.ButtonIngresar.Text = "INGRESAR";
            this.ButtonIngresar.UseVisualStyleBackColor = false;
            this.ButtonIngresar.Click += new System.EventHandler(this.ButtonIngresar_Click);
            // 
            // frmIngreso
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(492, 316);
            this.Controls.Add(this.textpassword);
            this.Controls.Add(this.txtcontraseña);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ButtonIngresar);
            this.Name = "frmIngreso";
            this.Text = "Ingreso";
            this.Load += new System.EventHandler(this.frmIngreso_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textpassword;
        private System.Windows.Forms.Label txtcontraseña;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button ButtonIngresar;
    }
}