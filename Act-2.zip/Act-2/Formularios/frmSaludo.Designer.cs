﻿namespace Act_2.Formularios
{
    partial class frmSaludo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtnombre = new System.Windows.Forms.TextBox();
            this.txtsaludar = new System.Windows.Forms.Button();
            this.txtName = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonre = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtnombre
            // 
            this.txtnombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnombre.Location = new System.Drawing.Point(206, 192);
            this.txtnombre.Name = "txtnombre";
            this.txtnombre.Size = new System.Drawing.Size(100, 22);
            this.txtnombre.TabIndex = 14;
            // 
            // txtsaludar
            // 
            this.txtsaludar.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txtsaludar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsaludar.Location = new System.Drawing.Point(127, 258);
            this.txtsaludar.Name = "txtsaludar";
            this.txtsaludar.Size = new System.Drawing.Size(87, 23);
            this.txtsaludar.TabIndex = 13;
            this.txtsaludar.Text = "Saludar";
            this.txtsaludar.UseVisualStyleBackColor = false;
            this.txtsaludar.Click += new System.EventHandler(this.txtsaludar_Click);
            // 
            // txtName
            // 
            this.txtName.AutoSize = true;
            this.txtName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(123, 190);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(77, 20);
            this.txtName.TabIndex = 12;
            this.txtName.Text = "Nombre : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(123, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(252, 40);
            this.label2.TabIndex = 11;
            this.label2.Text = "Este formulario captura el nombre \r\ny retorna un saludo";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(165, 82);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 16);
            this.label1.TabIndex = 10;
            this.label1.Text = "FORMULARIO OPCION 1";
            // 
            // buttonre
            // 
            this.buttonre.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonre.Location = new System.Drawing.Point(271, 258);
            this.buttonre.Name = "buttonre";
            this.buttonre.Size = new System.Drawing.Size(75, 23);
            this.buttonre.TabIndex = 15;
            this.buttonre.Text = "Regresar";
            this.buttonre.UseVisualStyleBackColor = false;
            this.buttonre.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmSaludo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(509, 345);
            this.Controls.Add(this.buttonre);
            this.Controls.Add(this.txtnombre);
            this.Controls.Add(this.txtsaludar);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frmSaludo";
            this.Text = "Saludo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtnombre;
        private System.Windows.Forms.Button txtsaludar;
        private System.Windows.Forms.Label txtName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonre;
    }
}