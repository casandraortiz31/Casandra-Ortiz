﻿namespace Act_2.Formularios
{
    partial class frmOperaciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textResultado = new System.Windows.Forms.TextBox();
            this.txtResultado = new System.Windows.Forms.Label();
            this.txtVal2 = new System.Windows.Forms.TextBox();
            this.txtVal1 = new System.Windows.Forms.TextBox();
            this.txtReversa = new System.Windows.Forms.Button();
            this.txtLimpiar = new System.Windows.Forms.Button();
            this.txtSuma = new System.Windows.Forms.Button();
            this.txtDivision = new System.Windows.Forms.Button();
            this.txtMultiplicacion = new System.Windows.Forms.Button();
            this.txtResta = new System.Windows.Forms.Button();
            this.txtNum2 = new System.Windows.Forms.Label();
            this.txtNum1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textResultado
            // 
            this.textResultado.Location = new System.Drawing.Point(259, 143);
            this.textResultado.Name = "textResultado";
            this.textResultado.Size = new System.Drawing.Size(100, 20);
            this.textResultado.TabIndex = 47;
            // 
            // txtResultado
            // 
            this.txtResultado.AutoSize = true;
            this.txtResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResultado.Location = new System.Drawing.Point(97, 141);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(101, 20);
            this.txtResultado.TabIndex = 46;
            this.txtResultado.Text = "Resultado :";
            // 
            // txtVal2
            // 
            this.txtVal2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVal2.Location = new System.Drawing.Point(259, 91);
            this.txtVal2.Name = "txtVal2";
            this.txtVal2.Size = new System.Drawing.Size(100, 22);
            this.txtVal2.TabIndex = 45;
            // 
            // txtVal1
            // 
            this.txtVal1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVal1.Location = new System.Drawing.Point(259, 39);
            this.txtVal1.Name = "txtVal1";
            this.txtVal1.Size = new System.Drawing.Size(100, 22);
            this.txtVal1.TabIndex = 44;
            // 
            // txtReversa
            // 
            this.txtReversa.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtReversa.Location = new System.Drawing.Point(327, 248);
            this.txtReversa.Name = "txtReversa";
            this.txtReversa.Size = new System.Drawing.Size(100, 50);
            this.txtReversa.TabIndex = 43;
            this.txtReversa.Text = "REGRESAR";
            this.txtReversa.UseVisualStyleBackColor = false;
            this.txtReversa.Click += new System.EventHandler(this.txtReversa_Click);
            // 
            // txtLimpiar
            // 
            this.txtLimpiar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtLimpiar.Location = new System.Drawing.Point(113, 248);
            this.txtLimpiar.Name = "txtLimpiar";
            this.txtLimpiar.Size = new System.Drawing.Size(96, 50);
            this.txtLimpiar.TabIndex = 42;
            this.txtLimpiar.Text = "LIMPIAR";
            this.txtLimpiar.UseVisualStyleBackColor = false;
            this.txtLimpiar.Click += new System.EventHandler(this.txtLimpiar_Click);
            // 
            // txtSuma
            // 
            this.txtSuma.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtSuma.Location = new System.Drawing.Point(59, 191);
            this.txtSuma.Name = "txtSuma";
            this.txtSuma.Size = new System.Drawing.Size(75, 23);
            this.txtSuma.TabIndex = 41;
            this.txtSuma.Text = "SUMAR";
            this.txtSuma.UseVisualStyleBackColor = false;
            this.txtSuma.Click += new System.EventHandler(this.txtSuma_Click);
            // 
            // txtDivision
            // 
            this.txtDivision.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtDivision.Location = new System.Drawing.Point(396, 191);
            this.txtDivision.Name = "txtDivision";
            this.txtDivision.Size = new System.Drawing.Size(75, 23);
            this.txtDivision.TabIndex = 40;
            this.txtDivision.Text = "DIVISION";
            this.txtDivision.UseVisualStyleBackColor = false;
            this.txtDivision.Click += new System.EventHandler(this.txtDivision_Click);
            // 
            // txtMultiplicacion
            // 
            this.txtMultiplicacion.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtMultiplicacion.Location = new System.Drawing.Point(270, 191);
            this.txtMultiplicacion.Name = "txtMultiplicacion";
            this.txtMultiplicacion.Size = new System.Drawing.Size(107, 23);
            this.txtMultiplicacion.TabIndex = 39;
            this.txtMultiplicacion.Text = "MULTIPLICACION";
            this.txtMultiplicacion.UseVisualStyleBackColor = false;
            this.txtMultiplicacion.Click += new System.EventHandler(this.txtMultiplicacion_Click);
            // 
            // txtResta
            // 
            this.txtResta.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtResta.Location = new System.Drawing.Point(167, 191);
            this.txtResta.Name = "txtResta";
            this.txtResta.Size = new System.Drawing.Size(75, 23);
            this.txtResta.TabIndex = 38;
            this.txtResta.Text = "RESTA";
            this.txtResta.UseVisualStyleBackColor = false;
            this.txtResta.Click += new System.EventHandler(this.txtResta_Click);
            // 
            // txtNum2
            // 
            this.txtNum2.AutoSize = true;
            this.txtNum2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNum2.Location = new System.Drawing.Point(81, 95);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(163, 20);
            this.txtNum2.TabIndex = 37;
            this.txtNum2.Text = "Ingresar el valor 2 :";
            // 
            // txtNum1
            // 
            this.txtNum1.AutoSize = true;
            this.txtNum1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNum1.Location = new System.Drawing.Point(81, 39);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(172, 20);
            this.txtNum1.TabIndex = 36;
            this.txtNum1.Text = "Ingresar el Valor 1 : ";
            // 
            // frmOperaciones
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(535, 350);
            this.Controls.Add(this.textResultado);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.txtVal2);
            this.Controls.Add(this.txtVal1);
            this.Controls.Add(this.txtReversa);
            this.Controls.Add(this.txtLimpiar);
            this.Controls.Add(this.txtSuma);
            this.Controls.Add(this.txtDivision);
            this.Controls.Add(this.txtMultiplicacion);
            this.Controls.Add(this.txtResta);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.txtNum1);
            this.Name = "frmOperaciones";
            this.Text = "frmOperaciones";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textResultado;
        private System.Windows.Forms.Label txtResultado;
        private System.Windows.Forms.TextBox txtVal2;
        private System.Windows.Forms.TextBox txtVal1;
        private System.Windows.Forms.Button txtReversa;
        private System.Windows.Forms.Button txtLimpiar;
        private System.Windows.Forms.Button txtSuma;
        private System.Windows.Forms.Button txtDivision;
        private System.Windows.Forms.Button txtMultiplicacion;
        private System.Windows.Forms.Button txtResta;
        private System.Windows.Forms.Label txtNum2;
        private System.Windows.Forms.Label txtNum1;
    }
}