﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Act_2.Formularios
{
    public partial class frmOperaciones : Form
    {
        public frmOperaciones()
        {
            InitializeComponent();
        }
        double Num1, Num2;

        private void txtResta_Click(object sender, EventArgs e)
        {
            double Resta;
            Num1 = Convert.ToDouble(txtVal1.Text);
            Num2 = Convert.ToDouble(txtVal2.Text);
            Resta = Num1 - Num2;
            textResultado.Text = String.Format("{0:F2}", Num1 - Num2);
        }

        private void txtMultiplicacion_Click(object sender, EventArgs e)
        {
            double Multiplicacion;
            Num1 = Convert.ToDouble(txtVal1.Text);
            Num2 = Convert.ToDouble(txtVal2.Text);
            Multiplicacion = Num1 * Num2;
            textResultado.Text = String.Format("{0:F2}", Num1 * Num2);
        }

        private void txtDivision_Click(object sender, EventArgs e)
        {
            double Division;
            Num1 = Convert.ToDouble(txtVal1.Text);
            Num2 = Convert.ToDouble(txtVal2.Text);
            Division = Num1 / Num2;
            textResultado.Text = String.Format("{0:F2}", Num1 / Num2);
        }

        private void txtLimpiar_Click(object sender, EventArgs e)
        {
            txtVal1.Clear();
            txtVal2.Clear();
            textResultado.Clear();
        }

        private void txtReversa_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 frmOperaciones = new Form1();
            frmOperaciones.Show();
            
        }

        private void txtSuma_Click(object sender, EventArgs e)
        {
            double Suma;
            Num1 = Convert.ToDouble(txtVal1.Text);
            Num2 = Convert.ToDouble(txtVal2.Text);
            Suma = Num1 + Num2;
            textResultado.Text = String.Format("{0:F2}", Num1 + Num2);
        }
    }
}
