﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Act_2.Formularios
{
    public partial class frmDatosClinicos : Form
    {
        public frmDatosClinicos()
        {
            InitializeComponent();
        }

        private void buttonrevers_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 frmDatosClinicos = new Form1();
            frmDatosClinicos.Show();
        }
    }
}
