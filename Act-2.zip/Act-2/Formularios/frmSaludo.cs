﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace Act_2.Formularios
{
    public partial class frmSaludo : Form
    {
        public frmSaludo()
        {
            InitializeComponent();
        }

        private void txtsaludar_Click(object sender, EventArgs e)
        {
            Clases.clssopcion1 Opcion1 = new Clases.clssopcion1();
            string MiSaludo = Opcion1.Saludar(txtnombre.Text);
            MessageBox.Show(MiSaludo);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 frmSaludo = new Form1();
            frmSaludo.Show();
        }
    } 
}
